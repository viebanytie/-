from __future__ import annotations

import math
import threading
from dataclasses import replace
from datetime import date
from pathlib import Path

from PyQt5.QtCore import Qt, QObject, QDate, QTimer, QPointF, QRectF, QPropertyAnimation, QEasingCurve, pyqtProperty, pyqtSignal
from PyQt5.QtGui import QColor, QPainter, QPen, QBrush, QLinearGradient, QConicalGradient, QPainterPath, QPolygonF, QFont
from PyQt5.QtWidgets import (QWidget, QFrame, QLabel, QVBoxLayout, QHBoxLayout, QGridLayout, QScrollArea,
    QComboBox, QDateEdit, QPushButton, QCheckBox, QTabWidget, QTableWidget, QTableWidgetItem, QHeaderView,
    QAbstractItemView, QDialog, QLineEdit, QFileDialog, QMessageBox, QTextBrowser)

from .analytics import build_report, export_report, aggregate, AnalyticsReport
from .workshops import WORKSHOPS
from .security import Permission

COLORS = ["#16B9B0", "#7C71F5", "#ED71A7", "#F6AD68", "#42A5F5", "#A3BC64"]


def pretty(value):
    return f"{value:,.2f}".replace(",", " ").rstrip("0").rstrip(".")


def duration(seconds):
    total=max(0,int(seconds));return f"{total//3600:02}:{total//60%60:02}:{total%60:02}"


def palette(dark):
    return {"bg":"#0D1322" if dark else "#F0F4FA", "card":"#161F32" if dark else "#FFFFFF",
        "text":"#E8EEF9" if dark else "#192B45", "muted":"#93A3BC" if dark else "#63748F",
        "grid":"#2B3850" if dark else "#DFE7F1"}


class AnimatedChart(QWidget):
    """Qt-painted charts with data interpolation, hover tracking and gradient fills."""
    def __init__(self, title, kind="line", suffix="", parent=None):
        super().__init__(parent)
        self.title,self.kind,self.suffix=title,kind,suffix
        self.labels=[];self.values=[];self.old=[];self.xy=[];self.dark=False;self._progress=1.0;self._hits=[];self._hover=-1
        self.setMinimumSize(300,255);self.setMouseTracking(True)
        self.anim=QPropertyAnimation(self,b"progress",self);self.anim.setDuration(650);self.anim.setEasingCurve(QEasingCurve.OutCubic)

    def get_progress(self):return self._progress
    def set_progress(self,v):self._progress=float(v);self.update()
    progress=pyqtProperty(float,get_progress,set_progress)

    def set_data(self,labels,values,xy=None):
        current=self.interpolated();self.anim.stop()
        self.old=current if list(labels)==self.labels and len(current)==len(values) else [0.0]*len(values)
        self.labels=list(labels);self.values=[float(v) for v in values];self.xy=xy or []
        self._hover=-1;self._progress=0;self.anim.setStartValue(0.0);self.anim.setEndValue(1.0);self.anim.start()

    def interpolated(self):
        return [o+(v-o)*self._progress for o,v in zip(self.old,self.values)]

    def mouseMoveEvent(self,event):
        pos=event.pos();hit=next((i for i,r in self._hits if r.contains(pos)), -1)
        if hit!=self._hover:self._hover=hit;self.update()
        super().mouseMoveEvent(event)

    def leaveEvent(self,event):self._hover=-1;self.update();super().leaveEvent(event)

    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.Antialiasing);pal=palette(self.dark)
        p.setPen(QPen(QColor(pal["grid"]),1));p.setBrush(QColor(pal["card"]));p.drawRoundedRect(QRectF(self.rect()).adjusted(1,1,-1,-1),18,18)
        p.setPen(QColor(pal["text"]));font=QFont("Segoe UI",11);font.setBold(True);p.setFont(font);p.drawText(QRectF(20,14,self.width()-40,30),Qt.AlignLeft|Qt.AlignVCenter,self.title)
        p.setFont(QFont("Segoe UI",9));self._hits=[]
        if not self.values:
            p.setPen(QColor(pal["muted"]));p.drawText(self.rect(),Qt.AlignCenter,"Нет данных за выбранный период");return
        vals=self.interpolated();area=QRectF(54,66,self.width()-80,self.height()-112)
        if self.kind=="radar":self._radar(p,area,vals,pal)
        elif self.kind=="donut":self._donut(p,area,vals,pal)
        elif self.kind=="bar":self._bars(p,area,vals,pal)
        else:self._line(p,area,vals,pal)
        if 0<=self._hover<len(vals):
            text=f"{self.labels[self._hover]} · {pretty(self.values[self._hover])} {self.suffix}"
            box=QRectF(16,self.height()-36,self.width()-32,26);p.setPen(Qt.NoPen);p.setBrush(QColor(pal["bg"]));p.drawRoundedRect(box,7,7)
            p.setPen(QColor(pal["text"]));p.drawText(box,Qt.AlignCenter,text)

    def _line(self,p,area,vals,pal):
        top=max(max(vals,default=0),1)*1.1
        p.setPen(QPen(QColor(pal["grid"]),1,Qt.DashLine))
        for n in range(5):
            y=area.bottom()-area.height()*n/4;p.drawLine(QPointF(area.left(),y),QPointF(area.right(),y))
            p.setPen(QColor(pal["muted"]));p.drawText(QRectF(2,y-9,46,18),Qt.AlignRight|Qt.AlignVCenter,pretty(top*n/4));p.setPen(QPen(QColor(pal["grid"]),1,Qt.DashLine))
        xs=[self.xy[i][0] for i in range(len(vals))] if self.kind=="scatter" and self.xy else list(range(len(vals)))
        xmin=min(xs,default=0);xmax=max(xs,default=1);span=max(xmax-xmin,1)
        pts=[QPointF(area.left()+area.width()*(x-xmin)/span if len(vals)>1 else area.center().x(),area.bottom()-area.height()*max(0,v)/top) for x,v in zip(xs,vals)]
        grad=QLinearGradient(area.topLeft(),area.bottomRight());grad.setColorAt(0,QColor(COLORS[0]));grad.setColorAt(1,QColor(COLORS[1]))
        if self.kind!="scatter":
            path=QPainterPath();path.moveTo(pts[0])
            for a,b in zip(pts,pts[1:]):
                mx=(a.x()+b.x())/2;path.cubicTo(QPointF(mx,a.y()),QPointF(mx,b.y()),b)
            fill=QPainterPath(path);fill.lineTo(pts[-1].x(),area.bottom());fill.lineTo(pts[0].x(),area.bottom());fill.closeSubpath()
            shade=QLinearGradient(area.topLeft(),area.bottomLeft());shade.setColorAt(0,QColor(22,185,176,85));shade.setColorAt(1,QColor(22,185,176,0));p.fillPath(fill,QBrush(shade));p.setPen(QPen(QBrush(grad),3));p.drawPath(path)
        for i,pt in enumerate(pts):
            p.setPen(Qt.NoPen);p.setBrush(QColor(COLORS[i%len(COLORS)] if self.kind=="scatter" else COLORS[0]));r=6 if i==self._hover else 3.5;p.drawEllipse(pt,r,r);self._hits.append((i,QRectF(pt.x()-10,pt.y()-10,20,20)))
        p.setPen(QColor(pal["muted"]))
        if self.kind=="scatter":p.drawText(QRectF(area.left(),area.bottom()+10,area.width(),20),Qt.AlignCenter,"Введённые часы → ФИКС, кг")
        else:
            for i in sorted(set([0,len(pts)//2,len(pts)-1])):
                p.drawText(QRectF(pts[i].x()-50,area.bottom()+10,100,20),Qt.AlignCenter,self.labels[i])

    def _bars(self,p,area,vals,pal):
        n=len(vals);maximum=max(max(vals),1);gap=area.height()/max(n,1)
        label_width=min(155,area.width()*0.4)
        for i,v in enumerate(vals):
            y=area.top()+i*gap+4;bar=QRectF(area.left()+label_width,y,max(2,(area.width()-label_width-52)*v/maximum),max(5,min(24,gap-8)))
            grad=QLinearGradient(bar.topLeft(),bar.topRight());grad.setColorAt(0,QColor(COLORS[i%6]));grad.setColorAt(1,QColor(COLORS[(i+1)%6]));p.setPen(Qt.NoPen);p.setBrush(grad);p.drawRoundedRect(bar,5,5)
            p.setPen(QColor(pal["text"]));p.drawText(QRectF(12,y,label_width+32,bar.height()),Qt.AlignVCenter,self.labels[i][:27]);p.drawText(QRectF(bar.right()+7,y,80,bar.height()),Qt.AlignVCenter,pretty(v));self._hits.append((i,QRectF(10,y,self.width()-20,gap)))

    def _radar(self,p,area,vals,pal):
        center=area.center();radius=min(area.width()*0.34,area.height()*0.40)
        def points(values):return QPolygonF([QPointF(center.x()+math.cos(-math.pi/2+i*2*math.pi/5)*radius*v,center.y()+math.sin(-math.pi/2+i*2*math.pi/5)*radius*v) for i,v in enumerate(values[:5])])
        p.setPen(QPen(QColor(pal["grid"]),1));p.setBrush(Qt.NoBrush)
        for k in range(1,6):p.drawPolygon(points([k/5]*5))
        outer=points([1]*5)
        for pt in outer:p.drawLine(center,pt)
        grad=QLinearGradient(area.topLeft(),area.bottomRight());grad.setColorAt(0,QColor(22,185,176,150));grad.setColorAt(1,QColor(237,113,167,120));p.setBrush(grad);p.setPen(QPen(QColor(COLORS[0]),2));polygon=points([max(0,min(1,v/100)) for v in vals]);p.drawPolygon(polygon)
        for i,pt in enumerate(outer):
            dx=pt.x()-center.x();dy=pt.y()-center.y();pos=QPointF(pt.x()+dx*0.28,pt.y()+dy*0.28)
            p.setPen(QColor(pal["muted"]));p.drawText(QRectF(pos.x()-70,pos.y()-16,140,32),Qt.AlignCenter,self.labels[i]);self._hits.append((i,QRectF(pos.x()-65,pos.y()-16,130,32)))

    def _donut(self,p,area,vals,pal):
        size=min(area.width(),area.height())*0.88;box=QRectF(area.center().x()-size/2,area.center().y()-size/2,size,size)
        total=sum(vals);angle=90.0
        p.setPen(QPen(QColor(pal["grid"]),18));p.drawEllipse(box)
        for i,v in enumerate(vals):
            span=360*v/total if total else 0;p.setPen(QPen(QColor(COLORS[i%6]),18,Qt.SolidLine,Qt.RoundCap));p.drawArc(box,int(angle*16),-int(max(0,span-3)*16));angle-=span
        p.setPen(QColor(pal["text"]));f=QFont("Segoe UI",22);f.setBold(True);p.setFont(f);p.drawText(box,Qt.AlignCenter,pretty(total));p.setFont(QFont("Segoe UI",9));p.setPen(QColor(pal["muted"]));p.drawText(QRectF(box.left(),box.center().y()+20,size,30),Qt.AlignCenter,self.suffix)


class MetricCard(QFrame):
    def __init__(self,label,color,parent=None):
        super().__init__(parent);self.setObjectName("MetricCard");self.setMinimumHeight(100);self.color=color;self.dark=False;self._hover=0.0
        l=QVBoxLayout(self);l.setContentsMargins(20,15,20,15);self.label=QLabel(label);self.value=QLabel("—");self.value.setStyleSheet("font-size:25px;font-weight:800;background:transparent;");l.addWidget(self.label);l.addWidget(self.value)
        self.anim=QPropertyAnimation(self,b"hover",self);self.anim.setDuration(160)
    def get_hover(self):return self._hover
    def set_hover(self,v):self._hover=v;self.update()
    hover=pyqtProperty(float,get_hover,set_hover)
    def enterEvent(self,e):self.anim.stop();self.anim.setStartValue(self._hover);self.anim.setEndValue(1.0);self.anim.start();super().enterEvent(e)
    def leaveEvent(self,e):self.anim.stop();self.anim.setStartValue(self._hover);self.anim.setEndValue(0.0);self.anim.start();super().leaveEvent(e)
    def paintEvent(self,e):
        p=QPainter(self);p.setRenderHint(QPainter.Antialiasing);pal=palette(self.dark);p.setPen(QPen(QColor(self.color if self._hover else pal["grid"]),1+self._hover));grad=QLinearGradient(0,0,self.width(),self.height());c=QColor(self.color);c.setAlpha(int(20+25*self._hover));grad.setColorAt(0,QColor(pal["card"]));grad.setColorAt(1,c);p.setBrush(grad);p.drawRoundedRect(QRectF(self.rect()).adjusted(1,1,-1,-1),16,16)


def table(columns):
    w=QTableWidget(0,len(columns));w.setHorizontalHeaderLabels([label for _,label in columns]);w.setProperty("columns",columns)
    w.setAlternatingRowColors(True);w.setSelectionBehavior(QAbstractItemView.SelectRows);w.setEditTriggers(QAbstractItemView.NoEditTriggers);w.verticalHeader().hide();w.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents);w.horizontalHeader().setStretchLastSection(True);w.setMinimumHeight(290);return w


def fill_table(w,rows):
    cols=w.property("columns");w.setSortingEnabled(False);w.setRowCount(len(rows))
    for i,r in enumerate(rows):
        for j,(key,label) in enumerate(cols):
            val=r.get(key,"");text=duration(val) if key.endswith("seconds") else pretty(val) if isinstance(val,(float,int)) else str(val)
            item=QTableWidgetItem(text);item.setData(Qt.UserRole,r)
            if isinstance(val,(float,int)):item.setData(Qt.DisplayRole,text)
            w.setItem(i,j,item)
    w.resizeRowsToContents()


class _ReportSignals(QObject):
    done=pyqtSignal(int,object,str)
    exported=pyqtSignal(str,str)


METRICS=[("orders","Наряды"),("hours","Часы строк"),("fixed_kg","ФИКС, кг"),("fixed_pay","ФИКС оплата, ₽"),("actual_pay","ФАКТ оплата, ₽")]


class AnalyticsWidget(QWidget):
    def __init__(self,owner):
        super().__init__();self.owner=owner;self.manager=owner.workshop_manager;self.user=owner.user;self.report=None;self._generation=0;self._running=False;self._exporting=False
        self.signals=_ReportSignals(self);self.signals.done.connect(self._loaded);self.signals.exported.connect(self._exported)
        root=QVBoxLayout(self);root.setContentsMargins(18,12,18,12);root.setSpacing(12)
        title=QLabel("Аналитика производства");title.setStyleSheet("font-size:25px;font-weight:800;background:transparent;");root.addWidget(title)
        self.caption=QLabel("Цеха · сотрудники · подразделения · мастера · сессии");root.addWidget(self.caption)
        filters=QHBoxLayout();self.shop=QComboBox();self.shop.addItem("Все цеха",None)
        for k,v in WORKSHOPS.items():self.shop.addItem(v,k)
        self.start=QDateEdit();self.end=QDateEdit();today=QDate.currentDate()
        for w in (self.start,self.end):w.setCalendarPopup(True);w.setDisplayFormat("dd.MM.yyyy")
        self.start.setDate(QDate(today.year(),today.month(),1));self.end.setDate(today)
        self.refresh=QPushButton("Обновить");self.refresh.clicked.connect(self.reload)
        self.charts=QCheckBox("Графики в Excel");self.charts.setChecked(True)
        self.export=QPushButton("Экспорт в Excel");self.export.setObjectName("PrimaryButton");self.export.clicked.connect(self.export_excel);self.export.setEnabled(False)
        for w in (QLabel("Цех:"),self.shop,QLabel("Период:"),self.start,QLabel("—"),self.end,self.refresh,self.charts,self.export):filters.addWidget(w)
        root.addLayout(filters);self.status=QLabel("Загрузка…");self.status.setWordWrap(True);root.addWidget(self.status)
        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setFrameShape(QFrame.NoFrame);root.addWidget(scroll,1)
        content=QWidget();scroll.setWidget(content);body=QVBoxLayout(content);body.setSpacing(14)
        cards=QHBoxLayout();self.cards=[]
        for i,(_,label) in enumerate(METRICS):
            c=MetricCard(label,COLORS[i]);cards.addWidget(c,1);self.cards.append(c)
        body.addLayout(cards)
        grid=QGridLayout();self.timeline=AnimatedChart("Динамика ФИКС по дням","line","кг");self.radar=AnimatedChart("Пятиугольный профиль · ведущий цех","radar","%");self.bars=AnimatedChart("Объём по цехам","bar","кг");self.donut=AnimatedChart("Распределение ФИКС","donut","кг")
        grid.addWidget(self.timeline,0,0,1,2);grid.addWidget(self.radar,0,2);grid.addWidget(self.bars,1,0,1,2);grid.addWidget(self.donut,1,2);grid.setColumnStretch(0,1);grid.setColumnStretch(1,1);grid.setColumnStretch(2,1);body.addLayout(grid)
        metric_line=QHBoxLayout();metric_line.addWidget(QLabel("Показатель графиков:"));self.metric=QComboBox();self.metric.addItems([label for _,label in METRICS]);self.metric.setCurrentIndex(2);self.metric.currentIndexChanged.connect(self._draw_charts);metric_line.addWidget(self.metric);metric_line.addStretch();body.addLayout(metric_line)
        self.pages=QTabWidget();body.addWidget(self.pages)
        employee_page=QWidget();el=QVBoxLayout(employee_page);self.employee_search=QLineEdit();self.employee_search.setPlaceholderText("Поиск сотрудника по ФИО · двойной щелчок открывает профиль");self.employee_search.textChanged.connect(self._fill_employees);el.addWidget(self.employee_search)
        self.employee_table=table([("employee","Сотрудник"),*METRICS]);self.employee_table.itemDoubleClicked.connect(self._employee_detail);el.addWidget(self.employee_table);self.pages.addTab(employee_page,"Сотрудники")
        self.department_table=table([("workshop","Цех"),("department","Подразделение"),*METRICS]);self.pages.addTab(self.department_table,"Подразделения")
        self.master_table=table([("workshop","Цех"),("master","Мастер наряда"),("created","Наряды мастера"),("edits","Правки нарядов")]);self.master_table.itemDoubleClicked.connect(self._master_detail);self.pages.addTab(self.master_table,"Мастера")
        self.account_table=table([("username","Логин"),("created","Создал"),("edits","Изменил"),("sessions","Сессии"),("total_seconds","Всего времени"),("longest_seconds","Самая длинная"),("shortest_seconds","Самая короткая"),("last_seconds","Последняя"),("last_state","Статус")]);self.account_table.itemDoubleClicked.connect(self._account_detail);self.pages.addTab(self.account_table,"Пользователи / сессии")
        self.details_table=table([("workshop","Цех"),("date","Дата"),("version","Наряд"),("employee","ФИО"),("department","Подразделение"),("work","Работа"),("hours","Часы"),("fixed_kg","ФИКС, кг"),("actual","ФАКТ, ед. работы")]);self.pages.addTab(self.details_table,"Детализация")
        note=QLabel("Двойной щелчок по сотруднику — его работы, цеха, динамика и профиль. По логину — история сессий.\nФИКС и ФАКТ — отдельные режимы расчёта; ФАКТ сравнивается внутри одного вида работы.");note.setWordWrap(True);body.addWidget(note)
        method=QPushButton("Методика расчёта и ограничения данных");method.clicked.connect(self._methodology);body.addWidget(method)
        self.shop.currentIndexChanged.connect(self.reload);self.start.dateChanged.connect(self.reload);self.end.dateChanged.connect(self.reload)
        self.timer=QTimer(self);self.timer.setInterval(60000);self.timer.timeout.connect(lambda:self.reload() if self.isVisible() and not self._running else None);self.timer.start()
        self.set_theme(owner.ui_settings.theme);QTimer.singleShot(0,self.reload)

    def set_theme(self,theme):
        self.dark=theme=="dark";p=palette(self.dark)
        self.setStyleSheet(f"AnalyticsWidget{{background:{p['bg']};}} QLabel{{color:{p['text']};background:transparent;}} QScrollArea,QScrollArea>QWidget>QWidget{{background:{p['bg']};border:none;}} QTableWidget{{background:{p['card']};color:{p['text']};alternate-background-color:{p['bg']};gridline-color:{p['grid']};border:1px solid {p['grid']};border-radius:10px;}} QHeaderView::section{{background:{p['card']};color:{p['muted']};padding:9px;border:0;}}")
        for c in self.findChildren(AnimatedChart):c.dark=self.dark;c.update()
        for c in self.cards:c.dark=self.dark;c.update()

    def reload(self,*_):
        self._generation+=1;gen=self._generation
        start=self.start.date().toPyDate();end=self.end.date().toPyDate();key=self.shop.currentData()
        if start>end:self.status.setText("Дата начала позже даты окончания");self.export.setEnabled(False);return
        self._running=True;self.status.setText("Чтение баз цехов…");self.export.setEnabled(False)
        def worker():
            try:r=build_report(self.manager,self.user,start,end,key);err=""
            except Exception as exc:r=None;err=str(exc)
            try:self.signals.done.emit(gen,r,err)
            except RuntimeError:pass
        threading.Thread(target=worker,name="SmartOrderAnalytics",daemon=True).start()

    def _loaded(self,generation,report,error):
        if generation!=self._generation:return
        self._running=False
        if error:self.status.setText("Ошибка аналитики: "+error);return
        self.report=report;self.export.setEnabled(True)
        status=f"{len(report.orders)} нарядов · {len(report.details)} строк · {len(report.employees)} сотрудников"
        if report.missing_workshops:status+=" · Базы ещё не созданы: "+", ".join(report.missing_workshops)
        self.status.setText(status)
        for (key,_),card in zip(METRICS,self.cards):
            value=len(report.orders) if key=="orders" else sum(r[key] for r in report.details);card.value.setText(pretty(value))
        self._draw_charts();self._fill_employees();fill_table(self.department_table,report.departments);fill_table(self.master_table,report.masters);fill_table(self.account_table,report.accounts);fill_table(self.details_table,report.details)

    def _draw_charts(self,*_):
        if not self.report:return
        r=self.report;key,label=METRICS[self.metric.currentIndex()];daily=sorted(r.daily,key=lambda x:x["date"])
        self.timeline.title=f"Динамика · {label}";self.timeline.suffix=label;self.timeline.set_data([x["date"][5:] for x in daily],[x[key] for x in daily])
        self.bars.title=f"Цеха · {label}";self.bars.suffix=label;self.bars.set_data([x["workshop"] for x in r.workshops],[x[key] for x in r.workshops])
        self.donut.suffix=label;self.donut.set_data([x["workshop"] for x in r.workshops],[x[key] for x in r.workshops])
        values=[]
        for field,_ in METRICS:
            all_vals=[x[field] for x in r.workshops];values.append(100*max(all_vals,default=0)/sum(all_vals) if sum(all_vals) else 0)
        self.radar.set_data(["Наряды","Часы","ФИКС, кг","ФИКС, ₽","ФАКТ, ₽"],values)

    def _fill_employees(self,*_):
        if self.report:fill_table(self.employee_table,[r for r in self.report.employees if self.employee_search.text().casefold() in r["employee"].casefold()])

    def _employee_detail(self,item):
        row=item.data(Qt.UserRole)
        if row and self.report:EmployeeAnalyticsDialog(self,row).exec_()

    def _account_detail(self,item):
        row=item.data(Qt.UserRole)
        if not row or not self.report:return
        dialog=QDialog(self);dialog.setWindowTitle("Сессии · "+row["username"]);dialog.resize(1150,560);l=QVBoxLayout(dialog)
        l.addWidget(QLabel(f"Всего: {duration(row.get('total_seconds',0))} · длинная: {duration(row.get('longest_seconds',0))} · короткая: {duration(row.get('shortest_seconds',0))} · последняя: {duration(row.get('last_seconds',0))}"))
        t=table([("workshop_name","Цех"),("session_started","Начало сеанса, UTC"),("started_at","Начало посещения, UTC"),("ended_at","Конец посещения, UTC"),("seconds_in_period","За период, сек"),("state","Статус")]);fill_table(t,[r for r in self.report.sessions if r["username"]==row["username"]]);l.addWidget(t)
        l.addWidget(QLabel("Открытая программа включает бездействие. Минимум и максимум — завершённые или прерванные сессии."));dialog.exec_()

    def _master_detail(self,item):
        row=item.data(Qt.UserRole)
        if not row or not self.report:return
        d=QDialog(self);d.setWindowTitle("Мастер наряда · "+row["master"]);d.resize(1150,600);l=QVBoxLayout(d)
        l.addWidget(QLabel(f"{row['workshop']} · {row['master']} · нарядов: {row['created']} · правок: {row['edits']}"))
        l.addWidget(QLabel("Здесь документы, где выбран этот мастер. Фактические создания и правки по логину — в «Пользователи / сессии»."))
        t=table([("date","Дата"),("version","Наряд"),("employee","Сотрудник"),("department","Подразделение"),("work","Работа"),("hours","Часы"),("fixed_kg","ФИКС, кг")]);l.addWidget(t);fill_table(t,[r for r in self.report.details if r["workshop_key"]==row["workshop_key"] and r["master"]==row["master"]]);d.exec_()

    def _methodology(self):
        if not self.report:return
        d=QDialog(self);d.setWindowTitle("Методика аналитики");d.resize(720,480);l=QVBoxLayout(d);b=QTextBrowser();b.setPlainText(self.report.methodology);l.addWidget(b);d.exec_()

    def export_excel(self):
        if not self.report or self._exporting:return
        try:self.manager.require(self.user,Permission.ANALYTICS_EXPORT)
        except Exception as exc:QMessageBox.warning(self,"Экспорт",str(exc));return
        path,_=QFileDialog.getSaveFileName(self,"Сохранить аналитику",f"SmartOrder_Аналитика_{self.report.start}_{self.report.end}.xlsx","Excel (*.xlsx)")
        if not path:return
        if not path.lower().endswith(".xlsx"):path+=".xlsx"
        self._exporting=True;self.export.setEnabled(False);r=self.report;charts=self.charts.isChecked();self.status.setText("Сохранение Excel…")
        def worker():
            try:export_report(Path(path),r,charts);err=""
            except Exception as exc:err=str(exc)
            try:self.signals.exported.emit(path,err)
            except RuntimeError:pass
        threading.Thread(target=worker,name="SmartOrderExcelAnalytics",daemon=True).start()

    def _exported(self,path,error):
        self._exporting=False;self.export.setEnabled(self.report is not None);self.status.setText("Ошибка экспорта: "+error if error else "Отчёт сохранён: "+path)


class EmployeeAnalyticsDialog(QDialog):
    def __init__(self,page,row):
        super().__init__(page);self.page=page;self.employee=row;self.setWindowTitle("Профиль сотрудника · "+row["employee"]);self.resize(1180,820)
        root=QVBoxLayout(self);heading=QLabel(row["employee"]);heading.setStyleSheet("font-size:24px;font-weight:800;");root.addWidget(heading)
        filters=QHBoxLayout();self.shop=QComboBox();self.shop.addItem("Все цеха в выбранном отчёте",None)
        keys={r["workshop_key"] for r in page.report.details if r["employee_key"]==row["employee_key"]}
        for k in WORKSHOPS:
            if k in keys:self.shop.addItem(WORKSHOPS[k],k)
        filters.addWidget(QLabel("Где работал:"));filters.addWidget(self.shop);filters.addStretch();self.export=QPushButton("Excel сотрудника");self.export.clicked.connect(self.export_employee);filters.addWidget(self.export);root.addLayout(filters)
        self.summary=QLabel();self.summary.setWordWrap(True);root.addWidget(self.summary)
        grid=QGridLayout();self.radar=AnimatedChart("Профиль относительно сотрудников отчёта","radar","%");self.line=AnimatedChart("Введённые часы по дням","line","ч");self.scatter=AnimatedChart("Время и объём работ","scatter","кг")
        grid.addWidget(self.radar,0,0);grid.addWidget(self.line,0,1);grid.addWidget(self.scatter,0,2);root.addLayout(grid)
        self.table=table([("workshop","Цех"),("date","Дата"),("version","Наряд"),("department","Подразделение"),("work","Работа"),("hours","Часы строки"),("fixed_kg","ФИКС, кг"),("actual","ФАКТ, ед. работы"),("fixed_pay","ФИКС, ₽"),("actual_pay","ФАКТ, ₽")]);root.addWidget(self.table,1)
        note=QLabel("Профиль: наряды, часы строк, ФИКС кг, ФИКС оплата, ФАКТ оплата — относительно максимума сотрудников отчёта.\nСвязь времени и объёма показана по датам; это описательная статистика. Между цехами сопоставление по полному ФИО.");note.setWordWrap(True);root.addWidget(note)
        self.setStyleSheet(page.styleSheet())
        for c in (self.radar,self.line,self.scatter):c.dark=page.dark
        self.shop.currentIndexChanged.connect(self.refresh);self.refresh()

    def refresh(self,*_):
        key=self.shop.currentData();self.rows=[r for r in self.page.report.details if r["employee_key"]==self.employee["employee_key"] and (key is None or r["workshop_key"]==key)]
        totals=aggregate(self.rows,["employee_key"]);t=totals[0] if totals else dict.fromkeys([k for k,_ in METRICS],0)
        self.summary.setText(f"Нарядов: {t['orders']} · Часы строк: {pretty(t['hours'])} · ФИКС: {pretty(t['fixed_kg'])} кг · ФИКС оплата: {pretty(t['fixed_pay'])} ₽ · ФАКТ оплата: {pretty(t['actual_pay'])} ₽\nФИКС / час: {pretty(t['fixed_kg']/t['hours']) if t['hours'] else '—'} кг/ч")
        peers=aggregate([r for r in self.page.report.details if key is None or r["workshop_key"]==key],["employee_key"])
        values=[100*t[field]/max([r[field] for r in peers] or [1]) if max([r[field] for r in peers] or [0]) else 0 for field,_ in METRICS]
        self.radar.set_data(["Наряды","Часы","ФИКС, кг","ФИКС, ₽","ФАКТ, ₽"],values)
        days=sorted(aggregate(self.rows,["date"]),key=lambda r:r["date"]);self.line.set_data([r["date"][5:] for r in days],[r["hours"] for r in days]);self.scatter.set_data([r["date"] for r in days],[r["fixed_kg"] for r in days],[(r["hours"],r["fixed_kg"]) for r in days]);fill_table(self.table,self.rows)

    def export_employee(self):
        try:self.page.manager.require(self.page.user,Permission.ANALYTICS_EXPORT)
        except Exception as exc:QMessageBox.warning(self,"Экспорт",str(exc));return
        path,_=QFileDialog.getSaveFileName(self,"Отчёт сотрудника","SmartOrder_Сотрудник.xlsx","Excel (*.xlsx)")
        if not path:return
        if not path.lower().endswith(".xlsx"):path+=".xlsx"
        r=self.page.report;orders={(x["workshop_key"],x["order_id"]) for x in self.rows}
        filtered=replace(r,workshop=self.shop.currentData(),details=self.rows,employees=aggregate(self.rows,["employee_key","employee"]),workshops=aggregate(self.rows,["workshop_key","workshop"]),departments=aggregate(self.rows,["workshop_key","workshop","department"]),daily=aggregate(self.rows,["date"]),orders=[x for x in r.orders if (x["workshop_key"],x["id"]) in orders],masters=[],accounts=[],sessions=[])
        try:export_report(Path(path),filtered,self.page.charts.isChecked());QMessageBox.information(self,"Экспорт","Отчёт сохранён")
        except Exception as exc:QMessageBox.warning(self,"Экспорт",str(exc))
