<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'availability_cohort', language 'ru', version '4.5'.
 *
 * @package     availability_cohort
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['anycohort'] = '(Любая Глобальная группа)';
$string['cleanuponcohortdeletion'] = 'Очистить ограничения при удалении глобальной группы';
$string['cleanuponcohortdeletion_desc'] = 'При включенном параметре все ограничения доступности, характерные для определенной глобальной группы, автоматически снимаются со всех активных элементов и разделов, как только эта группа будет удалена. Это предотвращает скрытие этих элементов и разделов из-за утраченного ограничения, которое больше никогда не может быть выполнено.<br /> Если параметр отключен, ограничения остаются в силе и отображаются как «{$a}».';
$string['description'] = 'Доступ только студентам, принадлежащим к определенной Глобальной группе';
$string['error_selectcohort'] = 'Вы должны выбрать Глобальную группу';
$string['missing'] = '(Не выбрана Глобальная группа)';
$string['pluginname'] = 'Ограничение по Глобальной группе';
$string['privacy:metadata'] = 'Плагин Ограничения по Глобальной группе не хранит никаких личных данных';
$string['requires_anycohort'] = 'Вы принадлежите <strong>какой-либо Глобальной группе</strong>';
$string['requires_cohort'] = 'Вы принадлежите к <strong>{$a}</strong>';
$string['requires_notanycohort'] = 'Вы <strong>не</strong> принадлежите к <strong>какой-либо Глобальной группеt</strong>';
$string['requires_notcohort'] = 'Вы <strong>не</strong> принадлежите к <strong>{$a}</strong>';
$string['title'] = 'Глобальная группа';
