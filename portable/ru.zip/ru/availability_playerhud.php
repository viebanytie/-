<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'availability_playerhud', language 'ru', version '4.5'.
 *
 * @package     availability_playerhud
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['description'] = 'Разрешить доступ на основе уровня, предметов или персонажа в PlayerHUD.';
$string['empty'] = 'Предметы не найдены';
$string['error_block_missing'] = 'Блок PlayerHUD не найден в этом курсе.';
$string['label_class_select'] = 'Требуемый персонаж:';
$string['label_item_qty'] = 'Минимальное количество:';
$string['label_item_select'] = 'Требуемый предмет:';
$string['label_min_level'] = 'Требуемый уровень:';
$string['label_type'] = 'Тип:';
$string['missing'] = '(Отсутствуют данные)';
$string['op_atleast'] = 'не менее';
$string['op_equal'] = 'ровно';
$string['op_less'] = 'менее';
$string['op_more'] = 'более';
$string['op_text_atleast'] = 'не менее';
$string['op_text_equal'] = 'ровно';
$string['op_text_less'] = 'менее';
$string['op_text_more'] = 'более';
$string['option_class'] = 'Персонаж';
$string['option_gamification'] = 'Геймификация включена';
$string['option_item'] = 'Наличие предмета';
$string['option_level'] = 'Минимальный уровень';
$string['pluginname'] = 'Условие доступности PlayerHUD';
$string['privacy:metadata'] = 'Плагин Условие доступности PlayerHUD не хранит никаких личных данных. Он оценивает правила доступа на основе данных, предоставленных блоком PlayerHUD.';
$string['requires_class'] = 'Ваш персонаж должен быть <strong>{$a}</strong>.';
$string['requires_gamification_active'] = 'У вас должна быть <strong>включена геймификация</strong>.';
$string['requires_item'] = 'У вас должно быть <strong>{$a->op} {$a->qty}x {$a->item}</strong>.';
$string['requires_level'] = 'Вы должны достичь <strong>Уровня {$a}</strong>.';
$string['title'] = 'PlayerHUD';
