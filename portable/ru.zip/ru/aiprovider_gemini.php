<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'aiprovider_gemini', language 'ru', version '4.5'.
 *
 * @package     aiprovider_gemini
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['action:generate_image:endpoint'] = 'Конечная точка API';
$string['action:generate_image:model'] = 'Модель ИИ';
$string['action:generate_text:endpoint'] = 'Конечная точка API';
$string['action:generate_text:model'] = 'Модель ИИ';
$string['action:generate_text:systeminstruction'] = 'Системная инструкция';
$string['action:summarise_text:endpoint'] = 'Конечная точка API';
$string['action:summarise_text:model'] = 'Модель ИИ';
$string['action:summarise_text:systeminstruction'] = 'Системная инструкция';
$string['apikey'] = 'Ключ API Gemini';
$string['endpoint_desc'] = 'Для Gemini 3 и собственных моделей изображений используется конечная точка Interactions. Существующие конфигурации устаревших моделей могут продолжать использовать конечную точку GenerateContent.';
$string['getallmodels_error'] = 'Перед этим необходимо ввести ключ API.';
$string['image_endpoint_unsupported'] = 'Для генерации изображений в Gemini требуется конечная точка API взаимодействий. Обновите конечную точку поставщика в настройках администрирования сайта.';
$string['image_model_unsupported'] = 'Настроенная модель изображения больше не поддерживается. Выберите стабильную собственную модель изображения Gemini 3.';
$string['image_quality_unsupported'] = 'Выбранная модель изображения поддерживает вывод только в разрешении 1K. Выберите стандартное качество или другую модель изображения.';
$string['image_response_missing'] = 'В ответе API Gemini отсутствует сгенерированное изображение.';
$string['pluginname'] = 'Провайдер API Gemini';
$string['privacy:metadata'] = 'Плагин провайдер API Gemini не хранит никаких персональных данных.';
$string['privacy:metadata:aiprovider_gemini:externalpurpose'] = 'Эта информация отправляется в API Gemini для формирования ответа. Настройки вашей учетной записи Gemini могут изменить способ хранения этих данных в Gemini.  Этим плагином данные пользователей не отправляются в Gemini и не сохраняются в LMS Moodle.';
$string['privacy:metadata:aiprovider_gemini:model'] = 'Модель, использованная для генерации ответа.';
$string['privacy:metadata:aiprovider_gemini:numberimages'] = 'Количество изображений, использованных при генерации изображений для ответа.';
$string['privacy:metadata:aiprovider_gemini:prompttext'] = 'Текст, введенный пользователем, который использовался для формирования ответа.';
$string['privacy:metadata:aiprovider_gemini:responseformat'] = 'Формат ответа при генерации изображений.';
