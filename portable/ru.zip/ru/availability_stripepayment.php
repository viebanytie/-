<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'availability_stripepayment', language 'ru', version '4.5'.
 *
 * @package     availability_stripepayment
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['accounts_email'] = 'Адрес электронной почты бухгалтерии';
$string['accounts_email_desc'] = 'Адрес электронной почты для получения внутренних уведомлений о платежах (квитанции студентам автоматически отправляются Stripe)';
$string['activity_not_found'] = 'Элемент курса не найден.';
$string['activitypaymentreport'] = 'Просмотреть отчет по платежам';
$string['allcourses'] = 'Все курсы';
$string['already_paid'] = 'Вы уже оплатили доступ к этому элементу курса.';
$string['amount'] = 'Сумма';
$string['backtocourse'] = 'Вернуться к курсу';
$string['cancelled'] = 'Отменено';
$string['clearfilter'] = 'Очистить фильтр';
$string['completed'] = 'Завершено';
$string['completedpayments'] = 'Завершенные платежи';
$string['continue_to_activity'] = 'Перейти к {$a}';
$string['copytransactionid'] = 'Скопировать ID транзакции';
$string['currency'] = 'Валюта';
$string['description'] = 'Требовать от студентов оплату через Stripe перед получением доступа к элементу курса.';
$string['dot'] = '.';
$string['downloadcsv'] = 'Скачать CSV';
$string['email_accounts_html_footer'] = 'Квитанция клиенту была автоматически отправлена Stripe.';
$string['email_accounts_html_heading'] = '✅ Получен новый платеж через Stripe.';
$string['email_accounts_html_title'] = 'Получен новый платеж';
$string['email_accounts_intro'] = 'Получен новый платеж через Stripe:';
$string['email_accounts_note'] = 'Примечание: квитанция клиенту автоматически отправлена Stripe.';
$string['email_accounts_row_activity'] = 'Элемент курса';
$string['email_accounts_row_course'] = 'Курс';
$string['email_accounts_row_date'] = 'Дата';
$string['email_accounts_subject'] = 'Новый платеж - {$a}';
$string['email_student_body'] = 'Ваш платеж успешно выполнен! Теперь у вас есть доступ к элементу курса.';
$string['email_student_subject'] = 'Платеж подтвержден - {$a}';
$string['enable'] = 'Включить платежи Stripe';
$string['enable_desc'] = 'Разрешить элементам курса требовать оплату через Stripe для доступа';
$string['error_amount_required'] = 'Введите корректную сумму больше 0.';
$string['error_itemname_required'] = 'Введите название позиции.';
$string['error_not_configured'] = 'Платеж Stripe настроен некорректно.';
$string['expired'] = 'Истекло';
$string['failed'] = 'Не удалось';
$string['filteractive'] = 'Фильтр:';
$string['id'] = 'ID';
$string['invalid_amount'] = 'Некорректная сумма платежа';
$string['invalid_amount_admin'] = 'Настроена некорректная сумма платежа. Пожалуйста, свяжитесь с администратором.';
$string['invalid_currency_admin'] = 'Настроена некорректная валюта. Пожалуйста, свяжитесь с администратором.';
$string['itemname'] = 'Название позиции';
$string['itemname_help'] = 'Название, которое будет показано пользователям во время оплаты';
$string['make_payment'] = 'Выполнить оплату';
$string['managetransactions'] = 'Управление платежными транзакциями Stripe';
$string['no_condition_found'] = 'Для этого элемента курса не найдено условие оплаты Stripe. Пожалуйста, свяжитесь с администратором.';
$string['nopayments'] = 'Для этого элемента курса пока нет записанных платежей.';
$string['not_paid'] = 'Вы не оплатили доступ к этому элементу курса.';
$string['pay_now'] = 'Оплатить сейчас';
$string['payingstudents'] = 'Оплатившие студенты';
$string['payment_cancelled'] = 'Платеж отменен';
$string['payment_completed'] = 'Платеж завершен';
$string['payment_config_error'] = 'Ошибка настройки платежа. Пожалуйста, обратитесь в службу поддержки.';
$string['payment_detail_amount'] = 'Сумма';
$string['payment_detail_id'] = 'ID платежа';
$string['payment_detail_item'] = 'Позиция';
$string['payment_details'] = 'Данные платежа';
$string['payment_failed'] = 'Платеж не прошел. Пожалуйста, попробуйте еще раз.';
$string['payment_failed_declined'] = 'Платеж не прошел: карта отклонена.';
$string['payment_in_progress'] = 'Платеж уже выполняется. Пожалуйста, подождите немного и попробуйте снова.';
$string['payment_not_found'] = 'Запись о платеже не найдена.';
$string['payment_required'] = 'Требуется оплата';
$string['payment_required_desc'] = 'Для доступа к «{$a->item}» требуется оплата в размере {$a->amount} {$a->currency}.';
$string['payment_success_notification'] = 'Платеж успешно выполнен! Теперь у вас есть доступ к этому контенту.';
$string['payment_successful'] = 'Платеж успешно выполнен! Выполняется перенаправление...';
$string['payment_successful_title'] = 'Платеж успешно выполнен';
$string['paymentreport'] = 'Отчет по платежам';
$string['payments'] = 'Платежи';
$string['pending'] = 'Ожидает обработки';
$string['pluginname'] = 'Ограничение доступа по оплате Stripe';
$string['privacy:metadata:payments'] = 'Записи платежей Stripe хранят данные о платежах, выполненных пользователями для доступа к элементам курса.';
$string['privacy:metadata:payments:amount'] = 'Списанная сумма платежа.';
$string['privacy:metadata:payments:cmid'] = 'Элемент курса (модуль курса), который разблокирует платеж.';
$string['privacy:metadata:payments:courseid'] = 'Курс, к которому относится платеж.';
$string['privacy:metadata:payments:sessionid'] = 'ID сессии Stripe Checkout для транзакции.';
$string['privacy:metadata:payments:status'] = 'Текущий статус платежа (например, завершен, ожидает обработки).';
$string['privacy:metadata:payments:timecreated'] = 'Время создания записи о платеже.';
$string['privacy:metadata:payments:userid'] = 'ID пользователя, выполнившего платеж.';
$string['processing'] = 'Обработка платежа...';
$string['redirecting_prefix'] = 'Автоматическое перенаправление через';
$string['second'] = 'секунду';
$string['seconds'] = 'секунд';
$string['settings_transactions_admin'] = 'Платежные транзакции Stripe';
$string['settings_transactions_heading'] = 'Платежные транзакции';
$string['settings_transactions_link'] = 'Просмотреть все платежные транзакции';
$string['status_ok'] = 'ok';
$string['stripe_not_configured'] = 'Stripe настроен некорректно. Пожалуйста, свяжитесь с администратором.';
$string['stripe_publishable_key'] = 'Публичный ключ Stripe';
$string['stripe_publishable_key_desc'] = 'Ваш публичный ключ Stripe из панели управления Stripe';
$string['stripe_secret_key'] = 'Секретный ключ Stripe';
$string['stripe_secret_key_desc'] = 'Ваш секретный ключ Stripe из панели управления Stripe';
$string['stripedashboard'] = '⧉ Панель управления Stripe';
$string['stripelink'] = '🔗 Stripe';
$string['stripepayment:managetransactions'] = 'Управление платежными транзакциями Stripe';
$string['student'] = 'Студент';
$string['tablenotexist'] = 'Таблица базы данных {$a} не существует';
$string['task_cleanup_pending'] = 'Очистка истекших ожидающих платежей';
$string['title'] = 'Платеж';
$string['totalpayments'] = 'Всего платежей';
$string['totalrevenue'] = 'Общий доход';
$string['transactionid'] = 'ID транзакции';
$string['transactionsreport'] = 'Платежные транзакции Stripe';
$string['unknownactivity'] = 'Неизвестный элемент курса';
$string['viewinstripe'] = 'Просмотреть в панели управления Stripe';
$string['webhook_already_processed'] = 'Уже обработано';
$string['webhook_empty_payload'] = 'Данные отсутствуют';
$string['webhook_error'] = 'Ошибка вебхука';
$string['webhook_invalid_payload'] = 'Некорректные данные';
$string['webhook_invalid_signature'] = 'Некорректная подпись';
$string['webhook_method_not_allowed'] = 'Метод не разрешен';
$string['webhook_missing_signature'] = 'Отсутствует подпись Stripe';
$string['webhook_payment_not_completed'] = 'Платеж не завершен';
$string['webhook_secret'] = 'Секрет конечной точки вебхука';
$string['webhook_secret_desc'] = 'Секрет конечной точки вебхука из Stripe';
$string['webhook_secret_not_configured'] = 'Секрет вебхука не настроен';
