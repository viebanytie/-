<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_readspeaker_embhl', language 'ru', version '4.5'.
 *
 * @package     block_readspeaker_embhl
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['africa'] = 'Африка';
$string['afrikaans'] = 'Африкаанс';
$string['arabic'] = 'Арабский';
$string['asia'] = 'Азия';
$string['basque'] = 'Баскский';
$string['block_settings_title'] = 'Настройка веб-программы чтения ReadSpeaker';
$string['block_title'] = 'Прослушать эту страницу с помощью ReadSpeaker';
$string['bulgarian'] = 'Болгарский';
$string['cachedef_readspeaker_tokens'] = 'Кэш токенов DocReader';
$string['catalan'] = 'Каталонский';
$string['chinese_mandarin'] = 'Китайский (мандаринский)';
$string['chinese_taiwanese'] = 'Китайский (тайваньский мандаринский)';
$string['croatian'] = 'Хорватский';
$string['customerid'] = 'ID клиента (обязательно)';
$string['customerid_help'] = 'Ваш ID клиента ReadSpeaker (например, «1234»).';
$string['customparams'] = 'Дополнительная опция: Пользовательские параметры';
$string['customparams_help'] = 'Укажите пользовательские параметры для кнопки «Прослушивание ReadSpeaker» (добавляется в дополнение к параметрам по умолчанию).';
$string['czech'] = 'Чешский';
$string['danish'] = 'Датский';
$string['disableinem'] = 'Дополнительная опция: Отключить в режиме редактирования.';
$string['disableinem_help'] = 'Установите этот флажок, чтобы отключить функциональность webReader в режиме редактирования. Блок по-прежнему будет отображаться на страницах, но кнопка «Слушать» и скрипты не будут загружаться в режиме редактирования.';
$string['docreader'] = 'Включить docReader';
$string['docreader_help'] = 'Установите флажок, чтобы включить docReader (docReader должен быть включен в вашей учетной записи ReadSpeaker).';
$string['dutch'] = 'Голландский';
$string['dutch_flemish'] = 'Голландский (фламандский)';
$string['dutch_frisian'] = 'Голландский (фризский)';
$string['east_asia'] = 'Восточная Азия';
$string['english_american'] = 'Английский (американский';
$string['english_australian'] = 'Английский (австралийский)';
$string['english_brittish'] = 'Английский (Великобритания)';
$string['english_indian'] = 'Английский (индийский)';
$string['english_newzealand'] = 'Английский (Новая Зеландия)';
$string['english_scottish'] = 'Английский (шотландский)';
$string['english_southafrican'] = 'Английский (южноафриканский)';
$string['estonian'] = 'Эстонский';
$string['europe'] = 'Европа';
$string['faroese'] = 'Фарерский';
$string['farsi'] = 'Фарси';
$string['finnish'] = 'Финский';
$string['french'] = 'Французский';
$string['french_belgian'] = 'Французский (бельгийский)';
$string['french_canadian'] = 'Французский (канадский)';
$string['gelician'] = 'Галисийский';
$string['german'] = 'Немецкий';
$string['greek'] = 'Греческий';
$string['header_config'] = 'Параметры конфигурации';
$string['header_config_help'] = 'Ниже вы найдете доступные параметры конфигурации для плагина ReadSpeaker webReader.';
$string['hebrew'] = 'Иврит';
$string['hindi'] = 'Хинди';
$string['hong_kong_cantonese'] = 'Гонконгский кантонский';
$string['hungarian'] = 'Венгерский';
$string['icelandic'] = 'Исландский';
$string['isindebele'] = 'Ндебеле';
$string['isixhosa'] = 'Кхоса';
$string['isizulu'] = 'Зулусский';
$string['italian'] = 'Итальянский';
$string['japanese'] = 'Японский';
$string['korean'] = 'Корейский';
$string['lang'] = 'Язык чтения (обязательно)';
$string['lang_help'] = 'Выберите язык чтения для кнопки «Слушать» (выбранный язык должен быть включен в вашей учетной записи ReadSpeaker).';
$string['latestscript'] = 'Дополнительные опции: Последняя версия скрипта';
$string['latestscript_help'] = 'Убедитесь, что при тестировании используется последняя версия скриптов webReader for Education (ВНИМАНИЕ: последние версии скриптов всегда будут автоматически обновляться с выходом новых версий webReader for Education).';
$string['latvian'] = 'Латышский';
$string['listen_titletext'] = 'Прослушать эту страницу с помощью ReadSpeaker';
$string['listentext'] = 'Слушать';
$string['lithuanian'] = 'Литовский';
$string['middle_east'] = 'Ближний Восток';
$string['mobileapp'] = 'Включить мобильный плагин';
$string['mobileapp_help'] = 'Необходимо включить плагин в приложении Moodle (также требуется, чтобы эта функция была включена в ReadSpeaker).';
$string['north_america'] = 'Северная Америка';
$string['norwegian_bokmal'] = 'Норвежский (Букмол)';
$string['norwegian_nynorsk'] = 'Норвежский (Нюнорск)';
$string['oceania'] = 'Океания';
$string['pixels'] = 'Положение мобильной панели инструментов';
$string['pixels_help'] = 'Укажите, на каком расстоянии от нижнего края экрана должна располагаться панель инструментов мобильного приложения (например, «130»).';
$string['pluginname'] = 'ReadSpeaker webReader';
$string['polish'] = 'Польский';
$string['portuguese'] = 'Португальский';
$string['portuguese_brazilian'] = 'Португальский (бразильский)';
$string['privacy:metadata'] = 'Блок ReadSpeaker не хранит никакой личной информации и отображает только кнопку «Слушать» ReadSpeaker.';
$string['readid'] = 'Идентификатор зоны чтения (обязательно)';
$string['readid_help'] = 'Идентификатор элемента уровня блока, который необходимо прочитать (например, «region-main»).';
$string['readspeaker_embhl'] = 'ReadSpeaker webReader';
$string['readspeaker_embhl:addinstance'] = 'Добавить новый блок webReader';
$string['readspeaker_embhl:edit'] = 'Редактировать настройки блока webReader';
$string['readspeaker_embhl:myaddinstance'] = 'Добавить новый блок webReader на страницу «Личный кабинет».';
$string['region'] = 'Регион';
$string['region_help'] = 'Выберите регион для своей установки ReadSpeaker.';
$string['restricted'] = 'Ограничено';
$string['romanian'] = 'Румынский';
$string['russian'] = 'Русский';
$string['sepedi'] = 'Сепеди';
$string['sesotho'] = 'Сесото';
$string['setswana'] = 'Сетсвана';
$string['showincontent'] = 'Размещение кнопки «Слушать»';
$string['showincontent_help'] = 'Кнопка «Слушать» по умолчанию размещена в блоке на боковой панели. Вы можете переместить плеер в начало контента.';
$string['showincontent_showinblock'] = 'Показать в блоке';
$string['showincontent_showincontent'] = 'Показать в контенте';
$string['siswati'] = 'Сисвати';
$string['south_america'] = 'Южная Америка';
$string['spanish_american'] = 'Испанский (американский)';
$string['spanish_argentinian'] = 'Испанский (аргентинский)';
$string['spanish_castilian'] = 'Испанский (кастильский)';
$string['spanish_columbian'] = 'Испанский (колумбийский)';
$string['spanish_latin_american'] = 'Испанский (латиноамериканский)';
$string['spanish_mexican'] = 'Испанский (мексиканский)';
$string['standard'] = 'Стандартный';
$string['statistics'] = 'Статистика: Отобразить информацию о странице';
$string['stats_help'] = 'Установите флажок, чтобы в статистике отображался путь к странице вместо URL-адреса страницы.';
$string['swedish'] = 'Шведский';
$string['swedish_finnish'] = 'Шведский (финский)';
$string['thai'] = 'Тайский';
$string['translation'] = 'Язык перевода';
$string['translation_help'] = 'Выберите язык страницы или язык чтения, который будет использоваться в качестве исходного языка (с которого будет производиться перевод).';
$string['translation_page'] = 'Язык страницы';
$string['translation_voice'] = 'Язык чтения';
$string['tshivenda'] = 'Тшивенда';
$string['turkish'] = 'Турецкий';
$string['ukrainian'] = 'Украинский';
$string['webreaderfeatures'] = 'Возможности веб-ридера';
$string['webreaderfeatures_help'] = 'Это устанавливает режим для webReader, который определяет, какие кнопки функций прослушивания webReader будут доступны.';
$string['welsh'] = 'Валлийский';
$string['xitsonga'] = 'Кшитсонга';
