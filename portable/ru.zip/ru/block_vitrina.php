<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_vitrina', language 'ru', version '4.5'.
 *
 * @package     block_vitrina
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['amountcourses'] = 'Количесто курсов';
$string['amountcourses_help'] = 'Количество курсов для отображения в главном окне.';
$string['catalog'] = 'Каталог';
$string['categories'] = 'Категории';
$string['categories_help'] = 'Выберите категории с курсами для отображения в главном окне.';
$string['catfilterview'] = 'Фильтр по категориям';
$string['catfilterview_default'] = 'По умолчанию';
$string['catfilterview_directory'] = 'Каталог';
$string['catfilterview_help'] = 'Выберите способ отображения фильтра по категориям:<br>
 - по умолчанию: отображается простой список категорий.<br>
 - древовидная структура: отображается древовидная структура с категориями.<br>
 - каталог: категории, имеющие подкатегории, не используются в качестве фильтра, а только в виде заголовка.';
$string['catfilterview_tree'] = 'Древовидная структура';
$string['comment_by'] = 'От {$a}';
$string['commentslabel'] = '{$a} комментирует';
$string['commentsmanager'] = 'Менеджер комментариев';
$string['commentsmanager_help'] = 'Выберите плагин для добавления комментариев к курсу.';
$string['commentsmodaltitle'] = 'Комментарии курса';
$string['commentstitle'] = 'Новые комментарии';
$string['commentstitlealternate'] = 'Рейтинги курсов';
$string['completed'] = 'Курс завершен';
$string['completepercent'] = '{$a}% завершено';
$string['countstars'] = 'Звезд - {$a}';
$string['coursecategory'] = 'Категория курса';
$string['coursedetail'] = 'Подробнее о курсе';
$string['coursedetailtitle'] = 'Курс: {$a->fullname}';
$string['courselinkcopiedtoclipboard'] = 'Ссылка на курс скопирована в буфер обмена';
$string['coverimagetype'] = 'Изображение на обложке';
$string['coverimagetype_default'] = 'Изображение блока по умолчанию';
$string['coverimagetype_generated'] = 'Текстура, сгенерированная случайным образом';
$string['coverimagetype_help'] = 'Опция, когда курс не имеет изображения';
$string['coverimagetype_none'] = 'Нет';
$string['customgrenroll'] = 'Запишитесь в выбранную группу';
$string['customtitle'] = 'Пользовательский заголовок';
$string['daystoupcoming'] = 'Дней до начала предстоящих курсов';
$string['daystoupcoming_help'] = 'Количество дней, в течение которых активные курсы будут отображаться в блочном представлении.';
$string['decimalpoints'] = 'Десятичные знаки';
$string['decimalpoints_help'] = 'Количество десятичных знаков, используемых в формате расчета стоимости.';
$string['defaultsort'] = 'Все курсы';
$string['detailinfo'] = 'Подробная информация';
$string['detailinfo_help'] = 'Общая информация о курсе';
$string['enroll'] = 'Зарегистрироваться';
$string['enrollavailablepremium'] = 'Регистрация доступна для пользователей премиум-класса.';
$string['enrolled'] = 'Вы зачислены!';
$string['enrolledended'] = 'Вы зачислены на этот курс, но Ваша регистрация не активна';
$string['enrollrequired'] = 'Для прохождения курса необходимо зарегистрироваться!';
$string['feeinfo'] = '{$a}';
$string['feeinfoinlist'] = '{$a}';
$string['filtercustomfields'] = 'Настраиваемые поля для фильтрации';
$string['filtercustomfields_help'] = 'Выберите пользовательские поля для фильтрации курсов в каталоге. Для фильтрации доступны только выбранные и помеченные поля.';
$string['fulltextsearch'] = 'Полнотекстовый поиск';
$string['gotocourse'] = 'Перейти к курсу';
$string['greats'] = 'Рейтинговые';
$string['hascourseview'] = 'Вам доступен этот курс!';
$string['htmlfooter'] = 'Нижний колонтитул блока';
$string['htmlheader'] = 'Заголовок блока';
$string['includecontactsinlist'] = 'Включить контактные данные в список курсов.';
$string['includecontactsinlist_help'] = 'Если эта функция включена, блок также будет отображать контактную информацию в списке курсов.';
$string['includecustomfieldsinlist'] = 'Включить пользовательские поля в список курсов';
$string['includecustomfieldsinlist_help'] = 'Если эта функция включена, блок также будет отображать пользовательские поля в списке курсов';
$string['includehiddencourses'] = 'Включить скрытые курсы';
$string['includehiddencourses_help'] = 'Если эта функция включена, блок также будет отображать скрытые (невидимые) курсы, если у пользователя есть к ним доступ.';
$string['license-cc-0'] = 'Пользовательское соглашение';
$string['license-cc-by'] = 'Creative Commons Attribution 4.0 International License (С указанием авторства)';
$string['license-cc-by-nc'] = 'Creative Commons Attribution-NonCommercial 4.0 International License (Некоммерческая)';
$string['license-cc-by-nc-nd'] = 'Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (Некоммерческая, без производных)';
$string['license-cc-by-nc-sa'] = 'Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (Некоммерческая, с сохранением условий)';
$string['license-cc-by-nd'] = 'Creative Commons Attribution-NoDerivatives 4.0 International License (Без производных)';
$string['license-cc-by-sa'] = 'Creative Commons Attribution-ShareAlike 4.0 International License (С сохранением условий)';
$string['licensefield'] = 'Лицензионное поле';
$string['licensefield_help'] = 'Поле для указания лицензии на курс.';
$string['loadmore'] = 'Загрузить больше курсов';
$string['mediafield'] = 'Медиа область';
$string['mediafield_help'] = 'Поле курса для указания URL-адреса специального видеокурса.';
$string['newblocktitle'] = 'Витрина курсов';
$string['nocoursesview'] = 'Нет курсов для отображения здесь.';
$string['nomorecourses'] = 'Вы дошли до конца';
$string['notenrollable'] = 'В настоящее время запись на курс недоступна';
$string['notvisible'] = 'Этот курс недоступен';
$string['opendetailstarget'] = 'Подробная информация о курсе по ссылке';
$string['opendetailstarget_blank'] = 'В новом окне';
$string['opendetailstarget_help'] = 'Выберите, где открыть страницу с подробной информацией о курсе.';
$string['opendetailstarget_self'] = 'В том же окне';
$string['paymentbutton'] = 'Оплата курса';
$string['paymentinfo'] = 'Доступные способы приобретения курса.';
$string['paymentmethods'] = 'Способ оплаты';
$string['paymentrequired'] = 'Этот курс платный';
$string['paymenturlfield'] = 'Поле URL для оплаты';
$string['paymenturlfield_help'] = 'Укажите URL платежной системы';
$string['pluginname'] = 'Витрина курсов';
$string['premium'] = 'Премиум';
$string['premiumcohort'] = 'Премиум-группа';
$string['premiumcohort_help'] = 'Саморегистрация должна быть связана с настроенной группой, чтобы пользователи премиум-класса могли регистрироваться. Если вы не хотите настраивать группу для каждого курса, не выбирайте группу здесь, а защитите саморегистрацию паролем, чтобы она была недоступна для всех пользователей.';
$string['premiumcoursefield'] = 'Поле для курса премиум-класса';
$string['premiumcoursefield_help'] = 'Поле курса используется для указания типа премиум-подписки. Если оно не указано, функциональность премиум-курсов обрабатываться не будет, но у пользователей с премиум-подпиской по-прежнему будет возможность записываться на любой курс.';
$string['premiumenrolledcourse'] = 'Курс для записи пользователей премиум-класса';
$string['premiumenrolledcourse_help'] = 'Пользователи, записавшиеся на курс, будут считаться премиум-пользователями.';
$string['premiumfield'] = 'Поле пользователя премиум-типа';
$string['premiumvalue'] = 'Код поля «Премиум»';
$string['privacy:metadata'] = 'Блок «Витрина курсов» сам по себе не хранит никаких данных.';
$string['ratingmanager'] = 'Менеджер по рейтингам';
$string['ratingmanager_help'] = 'Выберите плагин для использования в оценке курса.';
$string['ratings'] = 'Рейтинги';
$string['ratingslabel'] = 'Рейтинги - {$a}';
$string['recents'] = 'Открывающиеся курсы';
$string['relatedcourses'] = 'Смежные курсы';
$string['relatedlimit'] = 'Ограничение по смежным курсам';
$string['relatedlimit_help'] = 'Количество смежных курсов, отображаемых на странице с подробной информацией о курсе. Если установлено значение 0, смежные курсы отображаться не будут.';
$string['requireauth'] = 'Для записи на этот курс вам необходимо <a href="{$a}">войти в систему</a>.';
$string['returntocatalog'] = 'Назад к Каталогу';
$string['selectcategories'] = 'Выберите категорию курса';
$string['settingsheaderappearance'] = 'Появление';
$string['settingsheaderfields'] = 'Поля курса';
$string['settingsheaderfiltering'] = 'Фильтрация';
$string['settingsheaderpayment'] = 'Связанные со способами оплаты';
$string['sharecourse'] = 'Поделиться курсом';
$string['sharecoursedesc'] = 'Вы знаете кого-нибудь, кому может понравиться этот курс?<br /> <strong>Расскажите ему об этом</strong>';
$string['shopmanager'] = 'Менеджер';
$string['shopmanager_help'] = 'Выберите плагин, который будете использовать в качестве магазина.';
$string['showallcomments'] = 'Посмотреть все';
$string['showcustomfields'] = 'Показать пользовательские поля';
$string['showcustomfields_help'] = 'Отобразить пользовательские поля на странице с подробной информацией о курсе.';
$string['showicon'] = 'Только иконки';
$string['showlesscomments'] = 'Скрыть комментарии';
$string['showlongcustomfields'] = 'Показывать длинные пользовательские поля';
$string['showlongcustomfields_help'] = 'Отобразить пользовательские поля в разделе описания на странице с подробной информацией о курсе.';
$string['showmore'] = 'Показать больше ...';
$string['showmorecomments'] = 'Показать больше комментариев';
$string['showtext'] = 'Только текст';
$string['singleamountcourses'] = 'Количество курсов в блоке';
$string['singleamountcourses_help'] = 'Количество курсов для отображения в блоке.';
$string['socialnetworks'] = 'Социальные сети';
$string['socialnetworks_help'] = 'Каждая социальная сеть указывается построчно со следующей структурой: icon-name|URL.
В URL можно использовать ключи: {url}, {urlencoded} и {name}.';
$string['sortalphabetically'] = 'По алфавиту';
$string['sortbydefault'] = 'Сортировка по умолчанию';
$string['sortbydefault_help'] = 'Выберите порядок отображения курсов на вкладке «Все курсы».';
$string['sortbyfinishdate'] = 'По дате окончания курса';
$string['sortbystartdate'] = 'По дате начала курса';
$string['sortdefault'] = 'Порядок курсов';
$string['staticfilters'] = 'Статические фильтры';
$string['staticfilters_help'] = 'Выберите нужный фильтр для использования в каталоге.';
$string['summary'] = 'Краткое содержание';
$string['summary_help'] = 'Содержимое отображается в верхней части страницы со списком курсов и подробной информацией о курсе.';
$string['syncpremiumenrolmentstask'] = 'Задача синхронизации регистрации премиум-подписок';
$string['tabtitle_default'] = 'Все курсы';
$string['tabtitle_greats'] = 'Рейтинговые курсы';
$string['tabtitle_premium'] = 'Премиум';
$string['tabtitle_recents'] = 'Открывающиеся курсы';
$string['tabview'] = 'Вид вкладок';
$string['tabview_help'] = 'Выбирайте вид вкладок, если доступно несколько вариантов отображения.';
$string['templatetype'] = 'Тип шаблона';
$string['templatetype_help'] = 'Выберите шаблон, чтобы изменить внешний вид страниц блоков.';
$string['textandicon'] = 'Текст и иконки';
$string['tokenenroll'] = 'Регистрация с помощью токена';
$string['viewall'] = 'Смотреть все';
$string['viewsicons'] = 'Иконки для отображения';
$string['viewsicons_help'] = 'Выберите иконки для отображения в зависимости от режима просмотра, обычно для вкладок меню. По одной иконке на строку, со следующей структурой: viewname=typo/icon. Например: greats=i/star. Если иконка не указана, будет использоваться иконка по умолчанию. Доступные режимы просмотра: По умолчанию, Открывающиеся, Рейтинговые, Премиум';
$string['vitrina:addinstance'] = 'Добавлять новый блок «Витрина курсов»';
$string['vitrina:myaddinstance'] = 'Добавлять новый блок «Витрина курсов» в личный кабинет';
$string['waiting'] = 'В ожидании';
