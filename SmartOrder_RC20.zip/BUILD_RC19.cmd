@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0Build_SmartOrder.ps1"
if errorlevel 1 pause
