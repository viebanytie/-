"""RC20 additions on top of the existing, tested RC18 desktop UI."""
from __future__ import annotations

import logging
import threading
from datetime import datetime
from pathlib import Path

from PyQt5.QtCore import Qt, QEvent, QObject, QTimer, QRectF, QPointF, QPropertyAnimation, QEasingCurve, pyqtProperty, QUrl
from PyQt5.QtGui import QColor, QPainter, QPen, QLinearGradient, QFont, QDesktopServices
from PyQt5.QtWidgets import (QApplication, QWidget, QFrame, QHBoxLayout, QVBoxLayout, QLabel, QPushButton,
    QDialog, QDialogButtonBox, QRadioButton, QButtonGroup, QScrollArea, QSizeGrip, QTextBrowser, QMessageBox, QMenu, QActionGroup)

from . import heavy_ui
from .heavy_ui import RC18MainWindow, _set_logo, _RC18SupportDialog
from .config import APP_VERSION, network_root, resource_path, set_active_workshop, local_state_dir
from .security import Permission, ANALYTICS_ROLES, ACCOUNTING_ROLES, WORKSHOP_ROLES
from .workshops import WorkshopManager, WorkshopDatabase, SessionTracker, WORKSHOPS, allowed_workshops
from .analytics_ui import AnalyticsWidget


class TabMotion(QWidget):
    """Overlay animates hover, press and selection while native tabs retain behavior."""
    def __init__(self,bar):
        super().__init__(bar);self.bar=bar;self._rect=QRectF();self._hover=-1;self._pressed=False;self._amount=0.0
        self.setAttribute(Qt.WA_TransparentForMouseEvents);bar.setMouseTracking(True);bar.installEventFilter(self)
        self.anim=QPropertyAnimation(self,b"selection",self);self.anim.setDuration(220);self.anim.setEasingCurve(QEasingCurve.OutCubic)
        self.hover_anim=QPropertyAnimation(self,b"hoverAmount",self);self.hover_anim.setDuration(150);self.hover_anim.setEasingCurve(QEasingCurve.OutCubic)
        bar.currentChanged.connect(self.select);self.select(bar.currentIndex());self.show()
    def get_rect(self):return self._rect
    def set_rect(self,r):self._rect=r;self.update()
    selection=pyqtProperty(QRectF,get_rect,set_rect)
    def get_amount(self):return self._amount
    def set_amount(self,v):self._amount=v;self.update()
    hoverAmount=pyqtProperty(float,get_amount,set_amount)
    def fade_hover(self,value):
        self.hover_anim.stop();self.hover_anim.setStartValue(self._amount);self.hover_anim.setEndValue(float(value));self.hover_anim.start()
    def select(self,index):
        self.setGeometry(self.bar.rect());self.raise_()
        target=QRectF(self.bar.tabRect(index));self.anim.stop();self.anim.setStartValue(self._rect if not self._rect.isNull() else target);self.anim.setEndValue(target);self.anim.start()
    def eventFilter(self,obj,event):
        t=event.type()
        if t==QEvent.Resize:self.setGeometry(self.bar.rect());self._rect=QRectF(self.bar.tabRect(self.bar.currentIndex()))
        elif t==QEvent.MouseMove:
            index=self.bar.tabAt(event.pos())
            if index!=self._hover or self._amount==0:self._hover=index;self.fade_hover(17)
        elif t==QEvent.Leave:self.fade_hover(0)
        elif t==QEvent.MouseButtonPress:self._pressed=True;self.fade_hover(45)
        elif t==QEvent.MouseButtonRelease:self._pressed=False;self.fade_hover(17)
        return False
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.Antialiasing)
        if self._hover>=0 and self.bar.isTabEnabled(self._hover):
            r=QRectF(self.bar.tabRect(self._hover)).adjusted(2,2,-2,-2);p.setPen(Qt.NoPen);p.setBrush(QColor(22,185,176,int(self._amount)));p.drawRoundedRect(r,9,9)
        r=self._rect.adjusted(10,self._rect.height()-4,-10,-1)
        gradient=QLinearGradient(r.topLeft(),r.topRight());gradient.setColorAt(0,QColor("#16B9B0"));gradient.setColorAt(1,QColor("#7C71F5"));p.setPen(Qt.NoPen);p.setBrush(gradient);p.drawRoundedRect(r,2,2)


class TitleBar(QFrame):
    def __init__(self,owner):
        super().__init__(owner);self.owner=owner;self.drag=None;self.setObjectName("EnterpriseTitleBar");self.setFixedHeight(48)
        row=QHBoxLayout(self);row.setContentsMargins(12,4,6,4);row.setSpacing(6)
        self.title=QLabel("Smart Order — Формирование нарядов на работу");self.title.setStyleSheet("font-size:14px;font-weight:700;background:transparent;");row.addWidget(self.title);row.addStretch()
        self.bell=QPushButton("🔔");self.bell.setObjectName("NotificationBell");self.bell.setToolTip("Уведомления об изменениях Ваших нарядов");self.bell.clicked.connect(owner.show_notifications);self.bell.setVisible(owner.user.role in WORKSHOP_ROLES);row.addWidget(self.bell)
        self.badge=QPushButton(f"👤 {owner.user.username}  ·  {WORKSHOPS[owner.workshop]}  ▾");self.badge.setObjectName("UserWorkshopBadge");self.badge.setToolTip(f"{owner.user.role}\nНажмите, чтобы выбрать цех");self.badge.clicked.connect(owner.choose_workshop);row.addWidget(self.badge)
        for text,tip,callback in [("—","Свернуть",owner.showMinimized),("□","Развернуть / восстановить",self.toggle_max),("×","Закрыть",owner.close)]:
            b=QPushButton(text);b.setObjectName("WindowClose" if text=="×" else "WindowControl");b.setToolTip(tip);b.setFixedSize(36,30);b.clicked.connect(callback);row.addWidget(b)
        self.set_theme(owner.ui_settings.theme)
    def set_theme(self,theme):
        dark=theme=="dark";bg="#1C1C25" if dark else "#F6F8FC";text="#F0F3FA" if dark else "#243149"
        self.setStyleSheet(f"QFrame#EnterpriseTitleBar{{background:{bg};border:0;}} QLabel{{color:{text};}} QPushButton#UserWorkshopBadge{{color:{text};background:{'#26314A' if dark else '#E7EEF9'};border:1px solid {'#3C4D6C' if dark else '#CBD9EF'};border-radius:12px;padding:5px 13px;font-size:12px;min-height:22px;}} QPushButton#UserWorkshopBadge:hover{{border-color:#16B9B0;background:{'#2E4056' if dark else '#DAF3F0'};}} QPushButton#UserWorkshopBadge:pressed{{background:{'#1D5260' if dark else '#BCE6E2'};}} QPushButton#WindowControl,QPushButton#WindowClose{{border:0;background:transparent;color:{text};padding:0;min-height:20px;border-radius:7px;font-size:18px;}} QPushButton#WindowControl:hover{{background:{'#34415A' if dark else '#E0E7F2'};}} QPushButton#WindowClose:hover{{background:#D84962;color:white;}}")
    def toggle_max(self):
        if self.owner.isFullScreen():self.owner.showNormal()
        elif self.owner.isMaximized():self.owner.showNormal()
        else:self.owner.showMaximized()
    def mouseDoubleClickEvent(self,event):
        if event.button()==Qt.LeftButton:self.toggle_max()
    def mousePressEvent(self,event):
        if event.button()==Qt.LeftButton:
            handle=self.owner.windowHandle()
            if handle is not None and hasattr(handle,"startSystemMove") and handle.startSystemMove():return
            self.drag=event.globalPos()-self.owner.frameGeometry().topLeft()
    def mouseMoveEvent(self,event):
        if self.drag is not None and event.buttons()&Qt.LeftButton and not self.owner.isMaximized() and not self.owner.isFullScreen():self.owner.move(event.globalPos()-self.drag)
    def mouseReleaseEvent(self,event):self.drag=None


class WorkshopDialog(QDialog):
    def __init__(self,owner):
        super().__init__(owner);self.setWindowTitle("Выбор цеха");self.setMinimumWidth(490)
        root=QVBoxLayout(self);title=QLabel("Рабочее пространство");title.setStyleSheet("font-size:22px;font-weight:800;");root.addWidget(title)
        root.addWidget(QLabel(f"👤 {owner.user.username} · {owner.user.role}"));self.buttons=QButtonGroup(self);self.keys=list(WORKSHOPS)
        allowed=allowed_workshops(owner.user)
        for i,(k,v) in enumerate(WORKSHOPS.items()):
            b=QRadioButton(v+ (" · нет доступа" if k not in allowed else ""));b.setEnabled(k in allowed);b.setChecked(k==owner.workshop);b.setMinimumHeight(35);self.buttons.addButton(b,i);root.addWidget(b)
        note=QLabel("В каждом цехе своя номенклатура, сотрудники, мастера, наряды и черновики. Учётные записи общие.");note.setWordWrap(True);root.addWidget(note)
        box=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);box.button(QDialogButtonBox.Ok).setText("Перейти в цех");box.accepted.connect(self.accept);box.rejected.connect(self.reject);root.addWidget(box)
    def selected(self):return self.keys[self.buttons.checkedId()]


def read_news():
    # Never open a shared TXT in an external editor. OS read/write rights are
    # administered separately; the application exposes a read-only viewer only.
    configured=network_root()/"UPDATE_NEWS.txt"
    path=configured if configured.exists() else resource_path("UPDATE_NEWS.txt")
    raw=path.read_bytes()
    try:return path,raw.decode("utf-8-sig")
    except UnicodeDecodeError:return path,raw.decode("cp1251")


class MainWindow(RC18MainWindow):
    def __init__(self,db,user,manager=None,tracker=None):
        self.workshop_manager=manager or (db.manager if isinstance(db,WorkshopDatabase) else WorkshopManager(db))
        allowed=allowed_workshops(user)
        if not allowed:raise RuntimeError("У роли нет доступных цехов. Обратитесь к администратору.")
        if isinstance(db,WorkshopDatabase):key=db.workshop
        else:
            try:key=(local_state_dir()/f"workshop_{user.id}.txt").read_text().strip()
            except Exception:key=allowed[0]
            if key not in allowed:key=allowed[0]
            db=self.workshop_manager.database(key,user)
        self.workshop=key;set_active_workshop(key);self.session_tracker=tracker or SessionTracker(self.workshop_manager,user,key)
        self._switching=False;self._heartbeat_running=False;self.analytics=None
        self._notification_items=[];self._notification_count=0;self._notification_loading=False;self.notification_popup=None
        super().__init__(db,user)
        self.setWindowTitle("Smart Order — Формирование нарядов на работу")
        self.setWindowFlags(self.windowFlags()|Qt.FramelessWindowHint)
        self._telemetry_timer=QTimer(self);self._telemetry_timer.setInterval(60000);self._telemetry_timer.timeout.connect(self._heartbeat);self._telemetry_timer.start()
        from .live_ui import _NotificationSignals
        self._notification_signals=_NotificationSignals(self);self._notification_signals.loaded.connect(self._notifications_loaded)
        self._notification_timer=QTimer(self);self._notification_timer.setInterval(15000);self._notification_timer.timeout.connect(self.refresh_notifications)
        if user.role in WORKSHOP_ROLES:self._notification_timer.start();QTimer.singleShot(300,self.refresh_notifications)
        try:(local_state_dir()/f"workshop_{user.id}.txt").write_text(key)
        except OSError:pass

    def _build(self):
        self._enterprise_building=True
        super()._build()
        # Existing lazy pages use indexes 0..3; new pages are built by this class.
        self.tabs.insertTab(4,QWidget(),"Аналитика")
        for i,permission in [(0,Permission.ORDERS_VIEW),(1,Permission.CATALOG_VIEW),(2,Permission.EMPLOYEES_VIEW),(3,Permission.ADMIN_VIEW),(4,Permission.ANALYTICS_VIEW)]:self.tabs.setTabEnabled(i,self.can(permission) and (i!=4 or self.user.role in ANALYTICS_ROLES))
        self.tabs.setTabEnabled(5,True);self._tab_motion=TabMotion(self.tabs.tabBar())
        layout=self.centralWidget().layout();self.titlebar=TitleBar(self);layout.insertWidget(0,self.titlebar)
        self.zoom_message=QLabel('Во вкладке "Аналитика" Функция масштаба недоступна');self.zoom_message.setWordWrap(True);self.zoom_message.hide();layout.insertWidget(2,self.zoom_message)
        grip_row=QHBoxLayout();grip_row.setContentsMargins(0,0,0,0);grip_row.addStretch();self.grip=QSizeGrip(self);grip_row.addWidget(self.grip);layout.addLayout(grip_row)
        self.tabs.setCurrentIndex(0)
        self._enterprise_building=False

    def _tab_changed(self,index):
        if getattr(self,"_building_tab",False) or getattr(self,"_enterprise_building",False):return
        if index in (4,5):
            if index==4 and self.user.role not in ANALYTICS_ROLES:return
            if index not in self._loaded_tabs:
                self._building_tab=True
                try:
                    widget=AnalyticsWidget(self) if index==4 else self._build_about_tab()
                    if index==4:self.analytics=widget
                    self._replace_tab(index,widget,"Аналитика" if index==4 else "О приложении ⍰");self._loaded_tabs.add(index)
                finally:self._building_tab=False
            self._fade_current_tab()
        else:super()._tab_changed(index)
        self._update_zoom_mode()

    def _update_zoom_mode(self):
        if not hasattr(self,"zoom_message"):return
        analytic=self.tabs.currentIndex()==4
        mode=(analytic,self.ui_settings.theme)
        self.zoom_message.setVisible(analytic);self.zoom.setEnabled(not analytic);self.zoom.setVisible(not analytic);self.zoom_label.setVisible(not analytic)
        for label in self.centralWidget().findChildren(QLabel):
            if label.text()=="Масштаб:":label.setVisible(not analytic)
        for shortcut in getattr(self,"_rc18_shortcuts",[]):shortcut.setEnabled(not analytic)
        if getattr(self,"_zoom_mode",None)==mode:return
        self._zoom_mode=mode
        timer=getattr(self,"_rc18_zoom_timer",None)
        if timer is not None:timer.stop()
        # Restore the saved zoom on leaving analytics. Theme always remains active.
        from .heavy_styles import apply_apple_design
        if analytic:
            apply_apple_design(self,self.ui_settings.theme,100)
            font=QFont(QApplication.instance().font());font.setPointSizeF(12.0);QApplication.instance().setFont(font)
            if self.analytics:self.analytics.set_theme(self.ui_settings.theme)
        else:super()._rc18_commit_zoom()
        if hasattr(self,"titlebar"):self.titlebar.set_theme(self.ui_settings.theme)
        for browser in self.findChildren(QTextBrowser):
            if browser.property("largeAboutText"):
                font=QFont(browser.document().defaultFont());font.setPointSizeF(14*int(self.ui_settings.zoom)/100);browser.document().setDefaultFont(font)

    def _apply_zoom(self,value):
        if hasattr(self,"tabs") and self.tabs.currentIndex()==4:return
        return super()._apply_zoom(value)

    def _rc18_commit_zoom(self):
        if hasattr(self,"tabs") and self.tabs.currentIndex()==4:return
        return super()._rc18_commit_zoom()

    def _theme_toggled(self,checked):
        super()._theme_toggled(checked)
        if self.analytics:self.analytics.set_theme(self.ui_settings.theme)
        self._update_zoom_mode()

    def _sync_current_tab(self):
        if hasattr(self,"tabs") and self.tabs.currentIndex()==4:
            if self.analytics:self.analytics.reload()
            return
        return super()._sync_current_tab()

    def _build_admin_tab(self):
        tab=super()._build_admin_tab()
        content=tab.widget() if isinstance(tab,QScrollArea) else tab
        for label in content.findChildren(QLabel):
            if label.text() in ("Период:","Пользователь:"):
                label.setStyleSheet("background:#626262;color:#FFFFFF;padding:4px 7px;border-radius:4px;")
        label=QLabel("Общие учётные записи и сессии: "+str(self.workshop_manager.auth.path));label.setWordWrap(True);label.setTextInteractionFlags(Qt.TextSelectableByMouse);content.layout().addWidget(label)
        if self.user.role=="Администратор":
            b=QPushButton("Резервная копия учётных записей и сессий");b.clicked.connect(self.backup_identity);content.layout().addWidget(b)
        return tab

    def backup_identity(self):
        try:
            self.workshop_manager.require(self.user,Permission.USERS_MANAGE)
            folder=network_root()/"backups"/"identity";folder.mkdir(parents=True,exist_ok=True)
            target=folder/("identity_"+datetime.now().strftime("%Y-%m-%d_%H-%M-%S")+".db")
            self.workshop_manager.auth.backup_to(target)
            QMessageBox.information(self,"Резервная копия","Учётные записи и сессии сохранены:\n"+str(target))
        except Exception as exc:QMessageBox.warning(self,"Резервная копия",str(exc))

    def choose_workshop(self):
        if getattr(self,"workshop_menu",None) is not None and self.workshop_menu.isVisible():
            self.workshop_menu.hide();return
        menu=QMenu(self);self.workshop_menu=menu
        dark=self.ui_settings.theme=="dark"
        menu.setStyleSheet("QMenu{background:"+("#292C34;color:#FFFFFF;" if dark else "#FFFFFF;color:#202938;")+"border:1px solid #738097;border-radius:9px;padding:7px;font-size:14px;}QMenu::item{padding:10px 24px;border-radius:5px;}QMenu::item:selected{background:"+("#405575;" if dark else "#DDEAFB;")+"}QMenu::item:disabled{color:#858C99;}")
        heading=menu.addAction(self.user.username+" · "+self.user.role);heading.setEnabled(False);menu.addSeparator()
        group=QActionGroup(menu);group.setExclusive(True)
        for key,name in WORKSHOPS.items():
            action=menu.addAction(name);action.setCheckable(True);action.setChecked(key==self.workshop);action.setEnabled(key in allowed_workshops(self.user));action.setData(key);group.addAction(action)
            action.triggered.connect(lambda checked=False,k=key:self._switch_to_workshop(k))
        menu.popup(self.titlebar.badge.mapToGlobal(self.titlebar.badge.rect().bottomLeft()))

    def _switch_to_workshop(self,key):
        if key==self.workshop:return self
        QApplication.setOverrideCursor(Qt.WaitCursor)
        new_window=None
        try:
            db=self.workshop_manager.database(key,self.user)
            new_window=MainWindow(db,self.user,self.workshop_manager,self.session_tracker)
            self.session_tracker.switch(key)
        except Exception as exc:
            if new_window is not None:
                new_window._switching=True;new_window._rc4_exit_confirmed=True;new_window.close();new_window.deleteLater()
            set_active_workshop(self.workshop);QMessageBox.warning(self,"Цех",str(exc));return
        finally:QApplication.restoreOverrideCursor()
        app=QApplication.instance();app._smartorder_main_window=new_window
        new_window.showFullScreen() if self.isFullScreen() else new_window.showMaximized() if self.isMaximized() else new_window.show()
        self._switching=True;self._rc4_exit_confirmed=True;self.close();self.deleteLater()
        return new_window

    def open_diagnostics_center(self):
        from .live_ui import LiveDiagnosticsDialog
        dialog=LiveDiagnosticsDialog(self);dialog.setWindowState(dialog.windowState()|Qt.WindowMaximized);dialog.exec_()

    def refresh_notifications(self):
        if self.user.role not in WORKSHOP_ROLES or self._notification_loading:return
        self._notification_loading=True
        from .live_ui import notifications,unread_count
        def worker():
            try:items=notifications(self.workshop_manager,self.user);count=unread_count(self.workshop_manager,self.user);error=""
            except Exception as exc:items=[];count=0;error=str(exc)
            try:self._notification_signals.loaded.emit(items,count,error)
            except RuntimeError:pass
        threading.Thread(target=worker,name="SmartOrderNotifications",daemon=True).start()

    def _notifications_loaded(self,items,count,error):
        self._notification_loading=False
        if not error:
            self._notification_items=items;self._notification_count=count
            self.titlebar.bell.setText("🔔"+(f" {count}" if count else ""))
            self.titlebar.bell.setStyleSheet("QPushButton{border:1px solid "+("#ED71A7" if count else "#738097")+";border-radius:10px;padding:4px 10px;min-height:22px;font-size:14px;}QPushButton:hover{border-color:#16B9B0;}QPushButton:pressed{background:#263B55;}")
        self.titlebar.bell.setToolTip("Не удалось обновить уведомления: "+error if error else f"Непрочитанных уведомлений: {count}")
        if self.notification_popup and self.notification_popup.isVisible():self.notification_popup.render(items,error)

    def show_notifications(self):
        if self.user.role not in WORKSHOP_ROLES:return
        from .live_ui import NotificationPopup
        if self.notification_popup is not None:self.notification_popup.close();self.notification_popup.deleteLater()
        self.notification_popup=NotificationPopup(self)
        point=self.titlebar.bell.mapToGlobal(self.titlebar.bell.rect().bottomRight())
        screen=QApplication.screenAt(point) or QApplication.primaryScreen();bounds=screen.availableGeometry()
        x=max(bounds.left(),min(point.x()-460,bounds.right()-460));y=min(point.y()+6,bounds.bottom()-450)
        self.notification_popup.move(x,y);self.notification_popup.show();self.refresh_notifications()

    def open_notification_order(self,notice):
        window=self._switch_to_workshop(notice["workshop_key"])
        if window is None:return
        def show():
            try:
                order=window.db.get_order(int(notice["order_id"]))
                if order is None:raise RuntimeError("Версия наряда уже удалена политикой хранения или восстановлением базы.")
                dialog=heavy_ui.WorkOrderDialog(window.db,window.user,order,view_only=True,parent=window);dialog.exec_()
            except Exception as exc:QMessageBox.warning(window,"Наряд",str(exc))
        QTimer.singleShot(100,show)

    def _heartbeat(self):
        if self._heartbeat_running:return
        self._heartbeat_running=True
        def worker():
            try:self.session_tracker.heartbeat()
            except Exception:logging.exception("Не удалось записать heartbeat SmartOrder")
            finally:self._heartbeat_running=False
        threading.Thread(target=worker,name="SmartOrderSession",daemon=True).start()

    def closeEvent(self,event):
        super().closeEvent(event)
        if event.isAccepted():
            if hasattr(self,"_session_timer"):self._session_timer.stop()
            if hasattr(self,"_telemetry_timer"):self._telemetry_timer.stop()
            if hasattr(self,"_notification_timer"):self._notification_timer.stop()
            if self.notification_popup:self.notification_popup.close()
            if hasattr(self,"_db_ping_timer"):self._db_ping_timer.stop()
            if self.analytics:self.analytics.timer.stop()
            if not self._switching:
                try:self.session_tracker.heartbeat(close=True)
                except Exception:logging.exception("Не удалось закрыть сеанс SmartOrder")
        else:
            if hasattr(self,"_rc12_watch_timer"):self._rc12_watch_timer.start()

    def show_news(self):
        dialog=QDialog(self);dialog.setWindowTitle("Новости обновлений");dialog.resize(760,600);root=QVBoxLayout(dialog)
        title=QLabel("Новости обновлений");title.setStyleSheet("font-size:23px;font-weight:800;");root.addWidget(title)
        body=QTextBrowser();body.setReadOnly(True);root.addWidget(body,1)
        status=QLabel();status.setWordWrap(True);root.addWidget(status)
        def refresh():
            try:path,text=read_news();body.setPlainText(text);status.setText("Источник: "+str(path)+"\nИзменение исходного TXT — через системного администратора и права сетевой папки.")
            except Exception as exc:status.setText("Не удалось прочитать новости: "+str(exc))
        b=QPushButton("Обновить текст");b.clicked.connect(refresh);root.addWidget(b)
        stamp=[None]
        def poll():
            try:
                source=network_root()/"UPDATE_NEWS.txt"
                if not source.exists():source=resource_path("UPDATE_NEWS.txt")
                current=(str(source),source.stat().st_mtime_ns)
                if current!=stamp[0]:stamp[0]=current;refresh()
            except OSError as exc:status.setText("Не удалось прочитать новости: "+str(exc))
        timer=QTimer(dialog);timer.setInterval(3000);timer.timeout.connect(poll);timer.start();poll();dialog.exec_()

    def _about_browser(self,html,link_handler=None):
        browser=super()._about_browser(html,link_handler)
        browser.setProperty("largeAboutText",True)
        font=QFont("Segoe UI",14);browser.document().setDefaultFont(font)
        browser.setStyleSheet(browser.styleSheet()+" QTextBrowser{font-size:18px;} a{text-decoration:underline;}")
        return browser

    def _build_about_tab(self):
        # Keep the original live GIF, translucent text backings and original links.
        tab=RC18MainWindow._build_about_tab(self)
        layout=tab.layout();layout.setContentsMargins(28,18,28,18);layout.setSpacing(14)
        name=QLabel("Smart Order");name.setAlignment(Qt.AlignCenter)
        name.setStyleSheet("font-size:32px;font-weight:800;color:#FFFFFF;background:transparent;")
        layout.insertWidget(1 if layout.count() and isinstance(layout.itemAt(0).widget(),QLabel) and layout.itemAt(0).widget().pixmap() is not None else 0,name)
        for label in tab.findChildren(QLabel):
            if label.text().startswith("Enterprise Edition"):
                label.setText("Enterprise Edition");label.setStyleSheet("font-size:20px;color:#FFFFFF;background-color:rgba(0,0,0,132);padding:5px 10px;border-radius:6px;")
        for browser in tab.findChildren(QTextBrowser):
            if "Документация" not in browser.toPlainText():continue
            html=browser.toHtml();end=html.rfind("</body>")
            additions='<p><a href="news" style="color:#0A84FF;text-decoration:underline;">Новости обновлений</a></p><p><a href="rc20" style="color:#0A84FF;text-decoration:underline;">Цеха и аналитика — руководство RC20</a></p><p><a href="editnews" style="color:#0A84FF;text-decoration:underline;">Редактировать UPDATE_NEWS.txt — права администратора Windows</a></p><p style="color:#FFFFFF;background-color:#383838;">Новости берутся из UPDATE_NEWS.txt. Редактирование — через Edit_Update_News.cmd с запросом прав администратора Windows.</p>'
            browser.setHtml(html[:end]+additions+html[end:])
            frame=browser.parentWidget()
            for column in tab.findChildren(QVBoxLayout):
                index=column.indexOf(frame)
                if index>=0:column.setStretch(index,3)
            browser.anchorClicked.connect(lambda url:self.show_news() if url.toString()=="news" else self._open_rc19_guide() if url.toString()=="rc20" else self._edit_news() if url.toString()=="editnews" else None)
        for browser in tab.findChildren(QTextBrowser):
            if "Copyright" in browser.toPlainText():
                browser.setMinimumWidth(600);browser.setFixedHeight(48)
                browser.setHtml('<span style="color:#FFFFFF;background-color:#383838;">Powered by OITS&amp;ZI · Copyright © 2026 </span><a href="https://tmbsir.ru/" style="color:#0A84FF;text-decoration:underline;">tmbsir</a>')
            elif "Среда выполнения" in browser.toPlainText():
                browser.setHtml(browser.toHtml().replace("Версия: 1.0","Версия: "+APP_VERSION))
        return tab

    def _edit_news(self):
        path=network_root()/"Edit_Update_News.cmd"
        if not path.is_file():QMessageBox.warning(self,"Новости","Edit_Update_News.cmd отсутствует в сетевом корне. Скопируйте инструменты администратора из release.");return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def _open_guide(self):
        from .policy import ensure_user_guide_document
        path=ensure_user_guide_document()
        if path:QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def _open_rc19_guide(self):
        d=QDialog(self);d.setWindowTitle("Цеха и аналитика · RC20");d.resize(850,650);root=QVBoxLayout(d);b=QTextBrowser();root.addWidget(b)
        try:b.setPlainText(resource_path("README_RC20_RU.txt").read_text(encoding="utf-8-sig"))
        except Exception as exc:b.setPlainText("Не удалось открыть руководство: "+str(exc))
        d.exec_()
