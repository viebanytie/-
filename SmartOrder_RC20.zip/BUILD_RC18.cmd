@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Build_SmartOrder.ps1" -Clean
echo.
echo Build finished. Press any key to close.
pause >nul
